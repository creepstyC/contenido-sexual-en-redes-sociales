# Contenido sexual en redes sociales
Estudio estadístico que se centra en el manejo de desnudos compartidos por redes sociales.

## Colaboradores
+ Marlon Barajas Acelas [**creepstyC**](https://github.com/creepstyC)
+ Jose Gabriel Tomas Zapata [**Hyver00**](https://github.com/Hyver00)

## Fuentes de datos
+ Formulario de [**Encuesta**](https://forms.gle/8cNe6ZND89QsvYhv8) sobre el Envío de Fotos Desnudos por Redes Sociales (17 a 20 de Junio, 2024).
**Enlace**: *https://forms.gle/8cNe6ZND89QsvYhv8*